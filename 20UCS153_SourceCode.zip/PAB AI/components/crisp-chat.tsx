"use client";

import { useEffect } from "react";
import { Crisp } from "crisp-sdk-web";

export const CrispChat = () => {
  useEffect(() => {
    Crisp.configure("cfb1cee2-c63f-4382-808f-4ff8a9b8043b");
  }, []);

  return null;
};
