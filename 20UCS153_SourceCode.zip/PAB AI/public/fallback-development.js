/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@ducanh2912/next-pwa/dist/fallback.js":
/*!************************************************************!*\
  !*** ./node_modules/@ducanh2912/next-pwa/dist/fallback.js ***!
  \************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

eval(__webpack_require__.ts("__webpack_require__.r(__webpack_exports__);\nself.fallback = async (_)=>{\n    let { destination: e, url: A } = _, s = {\n        document: \"/offline\",\n        image: false,\n        audio: false,\n        video: false,\n        font: false\n    }[e];\n    return s ? caches.match(s, {\n        ignoreSearch: !0\n    }) : \"\" === e && false && 0 ? 0 : Response.error();\n};//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvQGR1Y2FuaDI5MTIvbmV4dC1wd2EvZGlzdC9mYWxsYmFjay5qcyIsIm1hcHBpbmdzIjoiO0FBQUE7QUFDQSxVQUFVLHlCQUF5QjtBQUNuQyxrQkFBa0IsVUFBcUM7QUFDdkQsZUFBZSxLQUFrQztBQUNqRCxlQUFlLEtBQWtDO0FBQ2pELGVBQWUsS0FBa0M7QUFDakQsY0FBYyxLQUFpQztBQUMvQyxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUssZ0JBQWdCLEtBQWlDLElBQUksQ0FBd0MsR0FBRyxDQUUvRjtBQUNOIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AZHVjYW5oMjkxMi9uZXh0LXB3YS9kaXN0L2ZhbGxiYWNrLmpzPzRiNjEiXSwic291cmNlc0NvbnRlbnQiOlsic2VsZi5mYWxsYmFjayA9IGFzeW5jIChfKT0+e1xuICAgIGxldCB7IGRlc3RpbmF0aW9uOiBlLCB1cmw6IEEgfSA9IF8sIHMgPSB7XG4gICAgICAgIGRvY3VtZW50OiBwcm9jZXNzLmVudi5fX1BXQV9GQUxMQkFDS19ET0NVTUVOVF9fLFxuICAgICAgICBpbWFnZTogcHJvY2Vzcy5lbnYuX19QV0FfRkFMTEJBQ0tfSU1BR0VfXyxcbiAgICAgICAgYXVkaW86IHByb2Nlc3MuZW52Ll9fUFdBX0ZBTExCQUNLX0FVRElPX18sXG4gICAgICAgIHZpZGVvOiBwcm9jZXNzLmVudi5fX1BXQV9GQUxMQkFDS19WSURFT19fLFxuICAgICAgICBmb250OiBwcm9jZXNzLmVudi5fX1BXQV9GQUxMQkFDS19GT05UX19cbiAgICB9W2VdO1xuICAgIHJldHVybiBzID8gY2FjaGVzLm1hdGNoKHMsIHtcbiAgICAgICAgaWdub3JlU2VhcmNoOiAhMFxuICAgIH0pIDogXCJcIiA9PT0gZSAmJiBwcm9jZXNzLmVudi5fX1BXQV9GQUxMQkFDS19EQVRBX18gJiYgQS5tYXRjaCgvXFwvX25leHRcXC9kYXRhXFwvLitcXC8uK1xcLmpzb24kL2kpID8gY2FjaGVzLm1hdGNoKHByb2Nlc3MuZW52Ll9fUFdBX0ZBTExCQUNLX0RBVEFfXywge1xuICAgICAgICBpZ25vcmVTZWFyY2g6ICEwXG4gICAgfSkgOiBSZXNwb25zZS5lcnJvcigpO1xufTsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./node_modules/@ducanh2912/next-pwa/dist/fallback.js\n"));

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/trusted types policy */
/******/ 	!function() {
/******/ 		var policy;
/******/ 		__webpack_require__.tt = function() {
/******/ 			// Create Trusted Type policy if Trusted Types are available and the policy doesn't exist yet.
/******/ 			if (policy === undefined) {
/******/ 				policy = {
/******/ 					createScript: function(script) { return script; }
/******/ 				};
/******/ 				if (typeof trustedTypes !== "undefined" && trustedTypes.createPolicy) {
/******/ 					policy = trustedTypes.createPolicy("nextjs#bundler", policy);
/******/ 				}
/******/ 			}
/******/ 			return policy;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/trusted types script */
/******/ 	!function() {
/******/ 		__webpack_require__.ts = function(script) { return __webpack_require__.tt().createScript(script); };
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/react refresh */
/******/ 	!function() {
/******/ 		if (__webpack_require__.i) {
/******/ 		__webpack_require__.i.push(function(options) {
/******/ 			var originalFactory = options.factory;
/******/ 			options.factory = function(moduleObject, moduleExports, webpackRequire) {
/******/ 				var hasRefresh = typeof self !== "undefined" && !!self.$RefreshInterceptModuleExecution$;
/******/ 				var cleanup = hasRefresh ? self.$RefreshInterceptModuleExecution$(moduleObject.id) : function() {};
/******/ 				try {
/******/ 					originalFactory.call(this, moduleObject, moduleExports, webpackRequire);
/******/ 				} finally {
/******/ 					cleanup();
/******/ 				}
/******/ 			}
/******/ 		})
/******/ 		}
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/compat */
/******/ 	
/******/ 	
/******/ 	// noop fns to prevent runtime errors during initialization
/******/ 	if (typeof self !== "undefined") {
/******/ 		self.$RefreshReg$ = function () {};
/******/ 		self.$RefreshSig$ = function () {
/******/ 			return function (type) {
/******/ 				return type;
/******/ 			};
/******/ 		};
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./node_modules/@ducanh2912/next-pwa/dist/fallback.js"](0, __webpack_exports__, __webpack_require__);
/******/ 	
/******/ })()
;