"use client";


import { useRouter } from "next/navigation";

import { ArrowRight,ImageIcon,VideoIcon, MessageSquare,Music,Code } from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const tools = [
  {
  label: "Conversation",
  icon: MessageSquare,
  color: "text-red-500",
  bgColor: "bg-red-500/10",
  href: "/conversation"
  },
  {
  label: "Music Generation",
  icon: Music,
  color: "text-yellow-500",
  bgColor: "bg-yellow-500/10",
  href: "/music"
  },
  {
  label: "Image Generation",
  icon: ImageIcon,
  color: "text-green-700",
  bgColor: "bg-green-500/10",
  href: "/image",
  },
  {
    label: 'Video Generation',
    icon: VideoIcon,
    color: "text-blue-700",
    bgColor: "bg-blue-700/10",
    href: '/video',
  },

  {
    label: 'Code Generation',
    icon: Code,
    color: "text-violet-700",
    bgColor: "bg-violet-700/10",
    href: '/code',
  }
  ]


export default function HomePage() {
  const router = useRouter();

  return (
    
    <div className=" min-h-screen bg-blue-100">
      <div className="mb-8 space-y-4">
        <h2 className="text-2xl md:text-4xl font-bold text-center">
          Welcome to PAB AI
        </h2>
        <p className="text-muted-foreground font-light text-sm md:text-lg text-center">
        Immerse in AI's Brilliance - Embark on a Journey of Discovery
        </p>
      </div>
      <div className="px-4 md:px-20 lg:px-32 space-y-4">
        {tools.map((tool) => (
          <Card onClick={() => router.push(tool.href)} key={tool.href} className="p-4 border-black/5 flex items-center justify-between hover:shadow-md transition cursor-pointer">
            <div className="flex items-center gap-x-4">
              <div className={cn("p-2 w-fit rounded-md", tool.bgColor)}>
                <tool.icon className={cn("w-8 h-8", tool.color)} />
              </div>
              <div className="font-semibold">
                {tool.label}
              </div>
            </div>
            <ArrowRight className="w-5 h-5" />
          </Card>
        ))}
      </div>
    </div>
    
  /*  <div className="min-h-screen bg-blue-100 flex flex-col justify-center items-center">
    <p>Dashboard page</p>
   </div> */
  );
}
